package ejercicio1;

import java.time.LocalDate;

public class PlayamarBank {

//	ATRIBUTOS

//  ATRIBUTOS DE CLASE
//	ATRIBUTOS FINALES DE CLASE	
//	Límite de descubierto por omisión para una cuenta: 0.0 euros.
	public final static double DEFAULT_MAX_DESCUBIERTO = 0.0;
//	Saldo inicial por omisión para una cuenta: 0.0 euros.
	public final static double DEFAULT_SALDO = 0.0;
//	Descubierto máximo permitido al crear una cuenta : -2000.0 euros.
	public final static double MAX_DESCUBIERTO = -2000;
//	Embargo máximo de una cuenta: 100.0 %.
	public final static double MAX_EMBARGO = 100;
//	Saldo máximo para una cuenta: 5.0E7 euros.
	public final static double MIN_EMBARGO = 0;
//	Embargo mínimo de una cuenta : 0.0%.
	public final static double MAX_SALDO = 50000000;
//	Año mínimo para la creación de una cuenta: 1900.
	public final static int MIN_YEAR = 1900;

//	ATRIBUTPS DE OBJETO
//	ATRIBUTOS VARIABLES DE OBJETO
	private double saldoInicial;
	private LocalDate fechaCreacion;
	private double limiteDescubierto;

//	Constructor con tres parámetros
	public PlayamarBank(double saldoInicial, LocalDate fechaCreacion, double limiteDescubierto)
			throws IllegalArgumentException {
		if (saldoInicial < 0) {
			throw new IllegalArgumentException("El saldo inicial no puede ser menor que 0");
		} else if (fechaCreacion.getYear() < MIN_YEAR) {
			throw new IllegalArgumentException("El año de creacion debe de ser mayor que 1900");
		} else if (limiteDescubierto < MAX_DESCUBIERTO) {
			throw new IllegalArgumentException("El limite de descubierto debe ser mayor a -2000");
		}

		this.saldoInicial = saldoInicial;
		this.fechaCreacion = fechaCreacion;
		this.limiteDescubierto = limiteDescubierto;
	}
}
