package ejercicio1;

public class PlayamarBankMain {

	public static void main(String[] args) {
		
		
		
	}

}
