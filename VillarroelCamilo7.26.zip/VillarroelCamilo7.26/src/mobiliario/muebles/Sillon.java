package mobiliario.muebles;

public class Sillon extends Asiento implements Ajustable{

}
