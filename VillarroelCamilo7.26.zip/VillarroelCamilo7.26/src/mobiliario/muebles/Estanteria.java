package mobiliario.muebles;

public class Estanteria extends Almacenaje {

}
