package mobiliario.muebles;

import mobiliario.pruebas.Modulo;

public interface Personalizable {

	public String obtenerModulo();

	public void anyadirModulo(Modulo modulo) throws IllegalStateException, NullPointerException;

	public void extraerModulo(Modulo modulo) throws IllegalStateException;
}
