package mobiliario.muebles;

public abstract class Almacenaje extends Mueble implements Personalizable {

}
