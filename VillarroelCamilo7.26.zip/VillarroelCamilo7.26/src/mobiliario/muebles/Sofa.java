package mobiliario.muebles;

public class Sofa extends Asiento{

}
